MY TOOLS
========

What is this ?
--------------

This is bash tools to simplify my life :
* Binaries compiled (in folder bin)
* Bash script (in folder script)
* Bash alias (in file bash_aliases)
* Bash functions (in file bash_completion)

How to install
--------------

Execute script 'install.sh' in the main folder of application

Other
-----

install `bat` and `fd` :
* https://github.com/sharkdp/bat
* https://github.com/sharkdp/bat
* https://github.com/sharkdp/bat
* https://github.com/nvbn/thefuck

