#!/usr/bin/env python


from editorconfig.main import main


if __name__ == "__main__":
    main()
